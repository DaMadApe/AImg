import numpy as np

from utils import *
from Game import Game

"""
Este archivo contiene la definición de la lógica de juego
con la clase Tablero y la definición de la interfaz que
define las interacciones entre el proceso de entrenamiento
y el juego en el tablero.
"""


class Tablero():
    """
    Representación del tablero de juego, incluyendo métodos
    para tirar en el tablero y validar los movimientos posibles.
    """

    def __init__(self, n=5):
        self.tablero = np.zeros((n, n), dtype=np.uint8)
        self.n = n
        self.score = [0, 0]
        # Movimientos_válidos = 3-self.tablero

    def __getitem__(self, idx):
        return self.tablero[idx]

    def __repr__(self):
        # Para definir lo que devuelve print(self)
        # Se invierte eje vertical al imprimir por conveniencia
        repr = '\n '
        for i in range(self.tablero.shape[1]):
            repr += str(i) + ' '
        sym = ['. ', '| ', '._', '|_']
        for j, fil in enumerate(self.tablero):
            for pos in fil[::-1]:
                repr = sym[pos] + repr
            repr = f'\n{j}' + repr
        return repr

    def validarTiro(self, y, x, mov):
        pos = self[y, x]
        # Validación de tiro
        cond = mov in [1, 2]
        if x < self.w-1 and y < self.h-1:
            cond &= (pos == 0 or (pos+mov == 3))
        else:
            # Puntos en la orilla del tablero están restringidos
            if x == self.w-1:
                cond &= mov == 1  # Sólo se vale ir vertical
            if y == self.h-1:
                cond &= mov == 2  # Sólo se vale ir horizontal
        return cond

    def mover(self, y, x, mov):
        """
        x: Columna
        y: Fila
        mov: Tiro, 1 para vertical, 2 para horizontal 
        """
        if self.validarTiro(y, x, mov):
            self.tablero[y, x] += mov
            p = self.evalScore(y, x, mov)
            return 1 + p  # Turno completo + los puntos ganados
        return 0  # Turno incompleto

    def evalScore(self, y, x, mov):
        """
        Calcular puntaje correspondiente a un tiro (y,x,mov)
        Revisar si la línea cierra algún cuadrado
        """
        p = 0
        if mov == 1:
            # pos%2 = (pos==1 or pos==3)
            # pos>1 = (pos==2 or pos==3)
            if self[y, x-1] == 3 and self[y+1, x-1] > 1:
                p += 1
            if self[y, x] == 3 and self[y, x+1] > 1 and self[y, x+1] % 2:
                p += 1
        else:
            if self[y, x-1] == 3 and self[y-1, x+1] % 2:
                p += 1
            if self[y, x] == 3 and self[y, x+1] % 2 and self[y, x+1] > 1:
                p += 1
        return p


class Timbiriche(Game):

    def __init__(self, n):
        self.n

    def getInitBoard(self):
        """
        Returns:
            startBoard: a representation of the board (ideally this is the form
                        that will be the input to your neural network)
        """
        tablero = np.zeros((self.n, self.n), dtype=np.uint8)
        return tablero

    def getBoardSize(self):
        """
        Returns:
            (x,y): a tuple of board dimensions
        """
        return (self.n, self.n)

    def getActionSize(self):
        """
        Returns:
            actionSize: number of all possible actions
        """
        size = 2*(self.n-1)**2 + 2*self.n
        return size

    def getNextState(self, board, player, action):
        """
        Input:
            board: current board
            player: current player (1 or -1)
            action: action taken by current player

        Returns:
            nextBoard: board after applying action
            nextPlayer: player who plays in the next turn (should be -player)
        """
        nextBoard = Tablero(self.n)
        nextBoard.tablero = np.copy(board)
        p = nextBoard.move(action)
        if p==1: # Tiro válido sin anotaciones
            nextPlayer = -player
        else:
            nextPlayer = player
        return nextBoard.tablero, nextPlayer

    def getValidMoves(self, board, player):
        """
        Input:
            board: current board
            player: current player

        Returns:
            validMoves: a binary vector of length self.getActionSize(), 1 for
                        moves that are valid from the current board and player,
                        0 for invalid moves
        """
        tablero = Tablero(self.n)
        tablero.tablero = np.copy(board)
        validMoves = []
        for y in range(self.n):
            for x in range(self.n):
                validMoves.append(board.validar(y,x,1))
                validMoves.append(board.validar(y,x,2))

        return validMoves

    def getGameEnded(self, board, player):
        """
        Input:
            board: current board
            player: current player (1 or -1)

        Returns:
            r: 0 if game has not ended. 1 if player won, -1 if player lost,
               small non-zero value for draw.
        """
        tablero_lleno = 3*(self.n-1)**2 + 3*(self.n-1)
        r = np.sum(board) == tablero_lleno
        return r

    def getCanonicalForm(self, board, player):
        """
        Input:
            board: current board
            player: current player (1 or -1)

        Returns:
            canonicalBoard: returns canonical form of board. The canonical form
                            should be independent of player. For e.g. in chess,
                            the canonical form can be chosen to be from the pov
                            of white. When the player is white, we can return
                            board as is. When the player is black, we can invert
                            the colors and return the board.
        """
        return board

    def getSymmetries(self, board, pi):
        """
        Input:
            board: current board
            pi: policy vector of size self.getActionSize()

        Returns:
            symmForms: a list of [(board,pi)] where each tuple is a symmetrical
                       form of the board and the corresponding pi vector. This
                       is used when training the neural network from examples.
        """

        pass

    def stringRepresentation(self, board):
        """
        Input:
            board: current board

        Returns:
            boardString: a quick conversion of board to a string format.
                         Required by MCTS for hashing.
        """
        return board.toString()


